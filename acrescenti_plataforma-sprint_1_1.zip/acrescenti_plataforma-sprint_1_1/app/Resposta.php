<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resposta extends Model
{
    //
 /*   public function conteudo()
    {
        return $this->belongsTo('App\Conteudo');
    }*/
}
